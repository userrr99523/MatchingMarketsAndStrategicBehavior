"""Recreate requested heatmaps conditional on scheme-specific prevalence.
Run: MPLCONFIGDIR=/private/tmp/prevalent_mpl python3 prevalent_instances/recreate_plots.py
"""
from pathlib import Path
import os
import ast
os.environ.setdefault('MPLCONFIGDIR', '/private/tmp/prevalent_mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
# filename, CSV, plotted column, prevalence column, divisor, palette
SPECS = [
('mallows_acc_women_30', 'mallows_accomplice', 'count_woman', 'count_woman', 30, 'coolwarm'),
('mallows_two_for_one_30', 'two_for_one_results_mallows', 'Two_for_one', 'Two_for_one', 900, 'plasma'),
('euclidean_mallows_self_30', 'euclidean_mallows_accomplice', 'self_manipulating_women', 'self_manipulating_women', 30, 'cividis'),
('euclidean_mallows_acc_women_30', 'euclidean_mallows_accomplice', 'count_woman', 'count_woman', 30, 'coolwarm'),
('euclidean_mallows_two_for_one_30', 'two_for_one_results_euclidean_Mallows', 'Two_for_one', 'Two_for_one', 900, 'plasma'),
('mallows_MA_self_30', 'mallows_MA_accomplice', 'self_manipulating_women', 'self_manipulating_women', 30, 'cividis'),
('mallows_MA_acc_women_30', 'mallows_MA_accomplice', 'count_woman', 'count_woman', 30, 'coolwarm'),
('mallows_MA_two_for_one_30', 'mallows_MA_two_for_one_results', 'Two_for_one', 'Two_for_one', 900, 'plasma'),
('trunc_count_mallows', 'mallows_gain_with_rank_diff', 'trunc_count', 'trunc_count', 10, 'viridis'),
('trunc_count_mall_MD', 'mallows_MD_gain_with_rank_diff', 'trunc_count', 'trunc_count', 10, 'viridis'),
('trunc_count_mall_MA', 'mallows_MA_gain_with_rank_diff', 'trunc_count', 'trunc_count', 10, 'viridis'),
('trunc_count_rev_euc', 'reverse_euclidean_gain_with_rank_diff', 'trunc_count', 'trunc_count', 10, 'viridis'),
('trunc_count_mall_euc', 'mallows_euclidean_gain_with_rank_diff', 'trunc_count', 'trunc_count', 10, 'viridis'),
('trunc_count_exp_euc', 'expectations_euclidean_gain_with_rank_diff', 'trunc_count', 'trunc_count', 10, 'viridis'),
('trunc_egal_mall_new', 'mallows_gain_egal', 'trunc_egal', 'trunc_manipulators', 20, 'viridis'),
('trunc_egal_mall_MD_new', 'mallows_MD_gain_egal', 'trunc_egal', 'trunc_manipulators', 20, 'viridis'),
('trunc_egal_mall_MA_new', 'mallows_MA_gain_egal', 'trunc_egal', 'trunc_manipulators', 20, 'viridis'),
('trunc_egal_rev_euc_new', 'reverse_euclidean_gain_egal', 'trunc_egal', 'trunc_manipulators', 20, 'viridis'),
('trunc_egal_mall_euc_new', 'mallows_euclidean_gain_egal', 'trunc_egal', 'trunc_manipulators', 20, 'viridis'),
('trunc_egal_exp_euc_new', 'expectations_euclidean_gain', 'trunc_egal', 'trunc_manipulators', 20, 'viridis'),
('expectations_euclidean_gain_avg_self_benefit', 'expectations_euclidean_gain', 'avg_self_benefit', 'num_self_manipulators', 10, 'cividis'),
('expectations_euclidean_gain_avg_best_benefit_acc', 'expectations_euclidean_gain', 'avg_best_benefit_acc', 'number_acc_manipulators', 10, 'coolwarm'),
('expectations_euclidean_avg_best_benefit_two', 'expectations_euclidean_gain', 'avg_best_benefit_two', 'number_two_manipulators', 10, 'plasma'),
('trunc_count_mallows_30', 'mallows_accomplice_with_rank_diff', 'trunc_count', 'trunc_count', 30, 'viridis'),
('trunc_count_mallows_50', 'mallows_gain_50_trunc_with_rank_diff', 'trunc_count', 'trunc_count', 50, 'viridis'),
('trunc_count_mallows_70', 'mallows_gain_70_self_with_rank_diff', 'trunc_count', 'trunc_count', 70, 'viridis'),
('mallows_self_avg_num_manipulators_50', 'mallows_gain_50', 'num_self_manipulators', 'num_self_manipulators', 50, 'cividis'),
('mallows_self_avg_num_manipulators_70', 'mallows_gain_70_self', 'num_self_manipulators', 'num_self_manipulators', 70, 'cividis'),

('mallows_MD_self_30', 'mallows_MD_accomplice', 'self_manipulating_women', 'self_manipulating_women', 30, 'cividis'),
('mallows_MD_acc_women_30', 'mallows_MD_accomplice', 'count_woman', 'count_woman', 30, 'coolwarm'),
('mallows_MD_two_for_one_30', 'MD_Mallows_two_for_one_results', 'Two_for_one', 'Two_for_one', 900, 'plasma'),
('mallows_self_10', 'mallows_gain', 'num_self_manipulators', 'num_self_manipulators', 10, 'cividis'),
('mallows_self_30', 'mallows_accomplice', 'self_manipulating_women', 'self_manipulating_women', 30, 'cividis'),
('mallows_euclidean_number_two_manipulators', 'mallows_euclidean_gain', 'number_two_manipulators', 'number_two_manipulators', 10, 'plasma'),
('mallows_euclidean_number_two_pairs', 'mallows_euclidean_gain', 'number_two_pairs', 'number_two_manipulators', 100, 'plasma'),
('mallows_euclidean_max_best_benefit_two', 'mallows_euclidean_gain', 'max_best_benefit_two', 'number_two_manipulators', 10, 'plasma'),
('mallows_MD_number_acc_manipulators', 'mallows_MD_gain', 'number_acc_manipulators', 'number_acc_manipulators', 10, 'coolwarm'),
('mallows_MD_number_acc_pairs', 'mallows_MD_gain', 'number_acc_pairs', 'number_acc_manipulators', 100, 'coolwarm'),
('mallows_MD_max_best_benefit_acc', 'mallows_MD_gain', 'max_best_benefit_acc', 'number_acc_manipulators', 10, 'coolwarm'),
('reverse_euclidean_acc_women', 'reverse_euclidean_accomplice', 'count_woman', 'count_woman', 30, 'coolwarm'),
('reverse_euclidean_gain_number_acc_pairs', 'reverse_euclidean_gain', 'number_acc_pairs', 'number_acc_manipulators', 100, 'coolwarm'),
('reverse_euclidean_gain_max_best_benefit_acc', 'reverse_euclidean_gain', 'max_best_benefit_acc', 'number_acc_manipulators', 10, 'coolwarm'),
('reverse_euclidean_number_two_manipulators', 'reverse_euclidean_gain', 'number_two_manipulators', 'number_two_manipulators', 10, 'plasma'),
('reverse_euclidean_number_two_pairs', 'reverse_euclidean_gain', 'number_two_pairs', 'number_two_manipulators', 100, 'plasma'),
('reverse_euclidean_max_best_benefit_two', 'reverse_euclidean_gain', 'max_best_benefit_two', 'number_two_manipulators', 10, 'plasma'),
('mallows_avg_best_benefit_acc', 'mallows_gain', 'avg_best_benefit_acc', 'number_acc_manipulators', 10, 'coolwarm'),
('mallows_gain_avg_self_benefit', 'mallows_gain', 'avg_self_benefit', 'num_self_manipulators', 10, 'cividis'),
('reverse_euclidean_gain_self_avg_num_manipulators', 'reverse_euclidean_gain', 'num_self_manipulators', 'num_self_manipulators', 10, 'cividis'),
('expectations_euclidean_self_30', 'expectations_euclidean_accomplice', 'self_manipulating_women', 'self_manipulating_women', 30, 'cividis'),
('expectations_euclidean_acc_women_30', 'expectations_euclidean_accomplice', 'count_woman', 'count_woman', 30, 'coolwarm'),
('expectations_euclidean_two_for_one_30', 'Expectations_Euclidean_two_for_one_results', 'Two_for_one', 'Two_for_one', 900, 'plasma'),
]

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-ambiguous",action="store_true")
    parser.add_argument("--only",nargs="+")
    parser.add_argument("--skip-existing",action="store_true")
    args = parser.parse_args()
    cache = {}
    summaries = []
    for name, source, value, prevalence, divisor, cmap in SPECS:
        if args.skip_existing and (OUT / f"{name}.pdf").exists():
            continue
        if args.only and name not in args.only:
            continue
        if args.skip_ambiguous and name in {"mallows_euclidean_number_two_manipulators", "mallows_euclidean_number_two_pairs"}:
            continue
        if source not in cache:
            cache[source] = pd.read_csv(ROOT / 'CSV_Files' / f'{source}.csv')
        df = cache[source]
        if value == 'trunc_count':
            computed = df['rank_differences'].map(
                lambda raw: sum(x > 0 for x in ast.literal_eval(raw)))
            if 'trunc_count' in df:
                np.testing.assert_array_equal(computed, df['trunc_count'])
            df['trunc_count'] = computed
        if prevalence == 'trunc_manipulators':
            # Women whose partners differ between the two extreme stable matchings.
            df['trunc_manipulators'] = [
                sum(a != b for a, b in zip(ast.literal_eval(m), ast.literal_eval(w)))
                for m, w in zip(df['men_opt_match'], df['women_opt_match'])
            ]
            np.testing.assert_array_equal(
                df['trunc_manipulators'] > 0, df['stability_count'] > 1)
        if value == 'num_self_manipulators' and 'benefit' in df:
            computed = df['benefit'].map(
                lambda raw: sum(x > 0 for x in ast.literal_eval(raw)))
            if 'num_self_manipulators' in df:
                np.testing.assert_array_equal(computed, df['num_self_manipulators'])
            df['num_self_manipulators'] = computed
        if 'phi_m' in df:
            keys = ['phi_m','phi_w']; labels = [r'$\phi_m$',r'$\phi_w$']
        elif 'phim' in df:
            keys = ['phim','phiw']; labels = [r'$\phi_m$',r'$\phi_w$']
        elif 'Phi1' in df:
            keys = ['Phi1','Phi2']; labels = [r'$\phi_m$',r'$\phi_w$']
        elif 'dimension' in df:
            keys = ['dimension','proportion' if 'proportion' in df else 'std']
            labels = ['Dimension','Proportion' if keys[1]=='proportion' else 'Standard Deviation']
        else:
            keys = ['Dimension','Std']; labels = ['Dimension','Standard Deviation']
        assert df[value].notna().all() and df[prevalence].notna().all()
        selected = df.loc[df[prevalence] > 0]
        assert (selected[prevalence] > 0).all()
        full = df.groupby(keys).size().rename('total_instances')
        counts = selected.groupby(keys).size().reindex(full.index,fill_value=0).rename('prevalent_instances')
        means = (selected.groupby(keys)[value].mean()/divisor).reindex(full.index).rename('conditional_mean')
        audit = pd.concat([full,counts,means],axis=1)
        # Independent arithmetic check against explicit sums / prevalent counts.
        sums = selected.groupby(keys)[value].sum().reindex(full.index,fill_value=0)
        expected = sums / counts.replace(0,np.nan) / divisor
        np.testing.assert_allclose(means,expected,equal_nan=True,rtol=1e-12)
        assert audit.loc[counts==0,'conditional_mean'].isna().all()
        audit.reset_index().to_csv(OUT / f'{name}_values.csv',index=False)
        matrix = means.unstack(keys[1]).reindex(index=sorted(df[keys[0]].unique()),columns=sorted(df[keys[1]].unique()))
        # Display undefined conditional means as zero on the full parameter grid.
        # The audit CSV retains NaN so undefined means remain distinguishable.
        matrix = matrix.fillna(0)
        fig, ax = plt.subplots(figsize=(8,6))
        sns.heatmap(matrix,ax=ax,annot=True,fmt='.2f',cmap=cmap,annot_kws={'size':18 if name=='mallows_euclidean_number_two_pairs' else 22})
        ax.set_facecolor('#eeeeee')
        ax.invert_yaxis()
        ax.set_xlabel(labels[1],fontsize=30)
        ax.set_ylabel(labels[0],fontsize=30)
        ax.tick_params(axis='both',labelsize=16)
        ax.collections[0].colorbar.ax.tick_params(labelsize=16)
        fig.tight_layout()
        fig.savefig(OUT / f'{name}.pdf',format='pdf')
        fig.savefig(OUT / f'{name}.png',dpi=120)
        plt.close(fig)
        summaries.append(dict(figure=name+'.pdf',source='CSV_Files/'+source+'.csv',value_column=value,prevalence_column=prevalence,normalization_divisor=divisor,total_instances=len(df),prevalent_instances=len(selected),undefined_cells=int(means.isna().sum())))
    if not summaries:
        print("No missing figures to generate.")
        return
    manifest = pd.DataFrame(summaries)
    manifest_path = OUT / 'calculation_manifest.csv'
    if manifest_path.exists():
        previous = pd.read_csv(manifest_path)
        manifest = pd.concat([previous.loc[~previous.figure.isin(manifest.figure)],manifest],ignore_index=True)
    manifest.to_csv(manifest_path,index=False)
    assert all((OUT / item['figure']).exists() for item in summaries)
    print(pd.DataFrame(summaries).to_string(index=False))

if __name__=='__main__':
    main()
