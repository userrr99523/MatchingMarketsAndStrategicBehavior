"""Verify market sizes from every original preference profile used by the plots."""
import ast
import json
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent


def parse_profile(raw):
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return ast.literal_eval(raw)


def expected_size(figure):
    stem = Path(figure).stem
    if stem.endswith('_70'):
        return 70
    if stem.endswith('_50'):
        return 50
    if stem.endswith('_30') or stem == 'reverse_euclidean_acc_women':
        return 30
    return 10


def validate_side(side, n):
    if len(side) != n:
        return False
    expected = set(range(1, n + 1))
    return all(len(ranking) == n and set(ranking) == expected for ranking in side)


def main():
    manifest = pd.read_csv(OUT / 'calculation_manifest.csv')
    audits = []
    failures = []
    for source, plots in manifest.groupby('source', sort=True):
        expected = {expected_size(name) for name in plots.figure}
        if len(expected) != 1:
            raise ValueError(f'Conflicting market sizes for {source}: {expected}')
        n = expected.pop()
        headers = pd.read_csv(ROOT / source, nrows=0).columns
        cols = ['preferences'] if 'preferences' in headers else (
            ['mpref', 'wpref'] if 'mpref' in headers else ['Mprefs', 'Wprefs'])
        rows = pd.read_csv(ROOT / source, usecols=cols)
        sizes = set()
        invalid = []
        for i, row in enumerate(rows.itertuples(index=False, name=None)):
            sides = parse_profile(row[0]) if len(cols) == 1 else (
                parse_profile(row[0]), parse_profile(row[1]))
            if len(sides) != 2:
                invalid.append(i)
                continue
            sizes.add((len(sides[0]), len(sides[1])))
            if not all(validate_side(side, n) for side in sides):
                invalid.append(i)
        audits.append(dict(source=source, expected_n=n, rows_checked=len(rows),
                           observed_market_sizes=str(sorted(sizes)),
                           invalid_profiles=len(invalid), plots_using_source=len(plots)))
        if invalid:
            failures.append((source, invalid[:10]))
        print(source, 'expected n=', n, 'observed=', sorted(sizes),
              'rows=', len(rows), 'invalid=', len(invalid), flush=True)
    pd.DataFrame(audits).to_csv(OUT / 'market_size_audit.csv', index=False)
    assert not failures, f'Preference profile failures: {failures}'
    print(f'PASS: {len(audits)} sources, {sum(a["rows_checked"] for a in audits)} instances, '
          f'{len(manifest)} plots.')


if __name__ == '__main__':
    main()
