# Normalized statistics over prevalent instances

Counts and permutation gains are divided by n; truncation egalitarian gain is divided by 2n. Each instance has equal weight, pooling all parameter settings. Prevalence is the fraction of all source instances with at least one successful manipulator of the corresponding type. Count and gain statistics use only those prevalent instances; no zero-filled heatmap cells enter these summaries. Permutation gain is the per-instance average benefit across all n agents, then divided by n, except where explicitly noted. Truncation gain uses trunc_egal divided by 2n. Max is the largest observed value of that per-instance metric, not the maximum individual benefit.

The n=4 files store maximum self benefit in avg_self_benefit. This report recomputes the average from the benefit lists to match n=10.

## n = 10

Each statistics cell lists **mean / median / max**.

| Model | Scheme | Prevalent / total | Prevalence | Manipulators / n | Normalized gain |
|----|----|---:|---:|---:|---:|
| Mallows | Self | 484 / 3600 | 13.44% | 0.1994 / 0.2000 / 0.5000 | 0.0407 / 0.0300 / 0.1600 |
| Mallows | Accomplice | 364 / 3600 | 10.11% | 0.2769 / 0.2000 / 0.7000 | 0.0829 / 0.0700 / 0.2900 |
| Mallows | Two-for-one | 3307 / 3600 | 91.86% | 0.2381 / 0.2000 / 0.7000 | 0.0887 / 0.0800 / 0.3300 |
| Mallows | Truncation | 953 / 3600 | 26.47% | 0.3320 / 0.3000 / 1.0000 | 0.3488 / 0.2500 / 1.4000 |
| Mallows MD | Self | 823 / 3600 | 22.86% | 0.1539 / 0.1000 / 0.5000 | 0.0384 / 0.0300 / 0.1600 |
| Mallows MD | Accomplice | 1357 / 3600 | 37.69% | 0.4010 / 0.4000 / 1.0000 | 0.1299 / 0.1000 / 0.4400 |
| Mallows MD | Two-for-one | 2544 / 3600 | 70.67% | 0.2324 / 0.2000 / 0.8000 | 0.0817 / 0.0700 / 0.5200 |
| Mallows MD | Truncation | 3456 / 3600 | 96.00% | 0.7967 / 0.9000 / 1.0000 | 1.7881 / 1.5000 / 4.5000 |
| Mallows MA | Self | 495 / 3600 | 13.75% | 0.1461 / 0.1000 / 0.4000 | 0.0341 / 0.0300 / 0.1300 |
| Mallows MA | Accomplice | 765 / 3600 | 21.25% | 0.3222 / 0.3000 / 0.8000 | 0.1093 / 0.1000 / 0.4000 |
| Mallows MA | Two-for-one | 2064 / 3600 | 57.33% | 0.2480 / 0.2000 / 0.8000 | 0.0734 / 0.0600 / 0.4000 |
| Mallows MA | Truncation | 1902 / 3600 | 52.83% | 0.4815 / 0.5000 / 1.0000 | 0.5901 / 0.5000 / 2.1000 |
| Reverse Euclidean | Self | 282 / 3000 | 9.40% | 0.1362 / 0.1000 / 0.4000 | 0.0333 / 0.0300 / 0.1400 |
| Reverse Euclidean | Accomplice | 491 / 3000 | 16.37% | 0.2743 / 0.2000 / 0.8000 | 0.1059 / 0.0900 / 0.4100 |
| Reverse Euclidean | Two-for-one | 2487 / 3000 | 82.90% | 0.1810 / 0.2000 / 0.6000 | 0.0615 / 0.0500 / 0.2900 |
| Reverse Euclidean | Truncation | 1184 / 3000 | 39.47% | 0.3509 / 0.3000 / 0.9000 | 0.4373 / 0.4000 / 1.6500 |
| Mallows Euclidean | Self | 736 / 3600 | 20.44% | 0.1825 / 0.2000 / 0.7000 | 0.0377 / 0.0300 / 0.1900 |
| Mallows Euclidean | Accomplice | 802 / 3600 | 22.28% | 0.2954 / 0.3000 / 0.9000 | 0.0919 / 0.0800 / 0.3500 |
| Mallows Euclidean | Two-for-one | 3006 / 3600 | 83.50% | 0.2009 / 0.2000 / 0.7000 | 0.0696 / 0.0600 / 0.3500 |
| Mallows Euclidean | Truncation | 1686 / 3600 | 46.83% | 0.3820 / 0.3000 / 1.0000 | 0.4397 / 0.3500 / 1.7000 |
| Expectations Euclidean | Self | 393 / 3000 | 13.10% | 0.2081 / 0.2000 / 0.5000 | 0.0374 / 0.0300 / 0.1400 |
| Expectations Euclidean | Accomplice | 277 / 3000 | 9.23% | 0.2404 / 0.2000 / 0.6000 | 0.0674 / 0.0600 / 0.2400 |
| Expectations Euclidean | Two-for-one | 2775 / 3000 | 92.50% | 0.2217 / 0.2000 / 0.6000 | 0.0821 / 0.0800 / 0.3000 |
| Expectations Euclidean | Truncation | 764 / 3000 | 25.47% | 0.3068 / 0.2000 / 0.8000 | 0.2918 / 0.2000 / 1.9000 |

## n = 4

Each statistics cell lists **mean / median / max**.

| Model | Scheme | Prevalent / total | Prevalence | Manipulators / n | Normalized gain |
|----|----|---:|---:|---:|---:|
| Mallows | Self | 54 / 1800 | 3.00% | 0.3935 / 0.5000 / 0.7500 | 0.1146 / 0.1250 / 0.1875 |
| Mallows | Accomplice | 52 / 1800 | 2.89% | 0.5385 / 0.5000 / 0.7500 | 0.2512 / 0.2500 / 0.4375 |
| Mallows | Two-for-one | 803 / 1800 | 44.61% | 0.2979 / 0.2500 / 0.7500 | 0.1058 / 0.0625 / 0.4375 |
| Mallows | Truncation | 297 / 1800 | 16.50% | 0.5934 / 0.5000 / 1.0000 | 0.3813 / 0.3750 / 1.0000 |
| Mallows MD | Self | 87 / 1800 | 4.83% | 0.3161 / 0.2500 / 0.7500 | 0.1027 / 0.0625 / 0.2500 |
| Mallows MD | Accomplice | 249 / 1800 | 13.83% | 0.5663 / 0.5000 / 1.0000 | 0.2593 / 0.2500 / 0.6250 |
| Mallows MD | Two-for-one | 532 / 1800 | 29.56% | 0.3003 / 0.2500 / 0.7500 | 0.1302 / 0.1250 / 0.4375 |
| Mallows MD | Truncation | 1237 / 1800 | 68.72% | 0.7607 / 0.7500 / 1.0000 | 0.6417 / 0.5000 / 1.5000 |
| Mallows MA | Self | 43 / 1800 | 2.39% | 0.3198 / 0.2500 / 0.5000 | 0.0974 / 0.1250 / 0.1875 |
| Mallows MA | Accomplice | 103 / 1800 | 5.72% | 0.5316 / 0.5000 / 1.0000 | 0.2561 / 0.2500 / 0.5625 |
| Mallows MA | Two-for-one | 413 / 1800 | 22.94% | 0.3366 / 0.2500 / 1.0000 | 0.1206 / 0.1250 / 0.5625 |
| Mallows MA | Truncation | 567 / 1800 | 31.50% | 0.6305 / 0.5000 / 1.0000 | 0.4248 / 0.3750 / 1.0000 |
| Reverse Euclidean | Self | 17 / 1500 | 1.13% | 0.2647 / 0.2500 / 0.5000 | 0.0735 / 0.0625 / 0.1250 |
| Reverse Euclidean | Accomplice | 51 / 1500 | 3.40% | 0.5196 / 0.5000 / 1.0000 | 0.2672 / 0.2500 / 0.5000 |
| Reverse Euclidean | Two-for-one | 523 / 1500 | 34.87% | 0.2887 / 0.2500 / 0.7500 | 0.1018 / 0.0625 / 0.3750 |
| Reverse Euclidean | Truncation | 251 / 1500 | 16.73% | 0.5747 / 0.5000 / 1.0000 | 0.3790 / 0.3750 / 0.8750 |
| Mallows Euclidean | Self | 88 / 1800 | 4.89% | 0.3523 / 0.2500 / 0.7500 | 0.1101 / 0.1250 / 0.2500 |
| Mallows Euclidean | Accomplice | 98 / 1800 | 5.44% | 0.5281 / 0.5000 / 0.7500 | 0.2449 / 0.2500 / 0.3750 |
| Mallows Euclidean | Two-for-one | 668 / 1800 | 37.11% | 0.3031 / 0.2500 / 0.7500 | 0.1088 / 0.0625 / 0.3750 |
| Mallows Euclidean | Truncation | 510 / 1800 | 28.33% | 0.5926 / 0.5000 / 1.0000 | 0.3794 / 0.3750 / 0.7500 |
| Expectations Euclidean | Self | 35 / 1500 | 2.33% | 0.4286 / 0.5000 / 0.7500 | 0.1161 / 0.1250 / 0.2500 |
| Expectations Euclidean | Accomplice | 22 / 1500 | 1.47% | 0.5000 / 0.5000 / 0.5000 | 0.2244 / 0.1875 / 0.3125 |
| Expectations Euclidean | Two-for-one | 662 / 1500 | 44.13% | 0.3006 / 0.2500 / 0.7500 | 0.1045 / 0.0625 / 0.3125 |
| Expectations Euclidean | Truncation | 136 / 1500 | 9.07% | 0.5699 / 0.5000 / 1.0000 | 0.3566 / 0.2500 / 0.8750 |
| Netflix | Self | 6 / 150 | 4.00% | 0.3333 / 0.2500 / 0.5000 | 0.0833 / 0.0625 / 0.1250 |
| Netflix | Accomplice | 7 / 150 | 4.67% | 0.5000 / 0.5000 / 0.5000 | 0.2679 / 0.2500 / 0.3750 |
| Netflix | Two-for-one | 57 / 150 | 38.00% | 0.3158 / 0.2500 / 0.7500 | 0.1086 / 0.0625 / 0.3750 |
| Netflix | Truncation | 37 / 150 | 24.67% | 0.5608 / 0.5000 / 1.0000 | 0.3682 / 0.3750 / 0.6250 |

## Source files

| Model | n | CSV |
|----|---:|----|
| Mallows | 10 | CSV_Files/mallows_gain.csv |
| Mallows MD | 10 | CSV_Files/mallows_MD_gain.csv |
| Mallows MA | 10 | CSV_Files/mallows_MA_gain.csv |
| Reverse Euclidean | 10 | CSV_Files/reverse_euclidean_gain.csv |
| Mallows Euclidean | 10 | CSV_Files/mallows_euclidean_gain.csv |
| Expectations Euclidean | 10 | CSV_Files/expectations_euclidean_gain.csv |
| Mallows | 4 | CSV_Files/4_mallows_with_rank_diff.csv |
| Mallows MD | 4 | CSV_Files/4_mallows_MD_with_rank_diff.csv |
| Mallows MA | 4 | CSV_Files/4_mallows_MA_with_rank_diff.csv |
| Reverse Euclidean | 4 | CSV_Files/4_reverse_euclidean_with_rank_diff.csv |
| Mallows Euclidean | 4 | CSV_Files/4_euclidean_mallows_with_rank_diff.csv |
| Expectations Euclidean | 4 | CSV_Files/4_expectations_euclidean_with_rank_diff.csv |
| Netflix | 4 | CSV_Files/netflix_preferences_with_rank_diff.csv |

The CSV report records the count and gain source for every row, including the paired n=10 truncation sources. Those paired files were verified to contain identical preferences and sample IDs in the same row order.
