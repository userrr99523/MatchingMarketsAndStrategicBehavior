"""Statistics pooled over individual instances; count/gain conditional on prevalence."""
import argparse
import ast
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
MODELS = [
    ('Mallows','mallows_gain','4_mallows_with_rank_diff'),
    ('Mallows MD','mallows_MD_gain','4_mallows_MD_with_rank_diff'),
    ('Mallows MA','mallows_MA_gain','4_mallows_MA_with_rank_diff'),
    ('Reverse Euclidean','reverse_euclidean_gain','4_reverse_euclidean_with_rank_diff'),
    ('Mallows Euclidean','mallows_euclidean_gain','4_euclidean_mallows_with_rank_diff'),
    ('Expectations Euclidean','expectations_euclidean_gain','4_expectations_euclidean_with_rank_diff'),
]
SCHEMES = [
    ('Self','num_self_manipulators','avg_self_benefit','self_freq_instance','benefit'),
    ('Accomplice','number_acc_manipulators','avg_best_benefit_acc','acc_freq_instance','best_benefits_per_woman_acc'),
    ('Two-for-one','number_two_manipulators','avg_best_benefit_two','two_freq_instance','best_benefits_per_woman_two'),
]


def parse(raw):
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return ast.literal_eval(raw)


def describe(values):
    if len(values) == 0:
        return dict(mean=np.nan,median=np.nan,max=np.nan)
    # Check aggregation independently using the observed empirical distribution.
    values=np.asarray(values,dtype=float)
    support,frequencies=np.unique(values,return_counts=True)
    mean=float(values.mean())
    np.testing.assert_allclose(mean,np.dot(support,frequencies)/len(values),rtol=1e-12)
    return dict(mean=mean,median=float(np.median(values)),max=float(values.max()))


def read(source,n):
    path=ROOT/'CSV_Files'/f'{source}.csv'
    df=pd.read_csv(path)
    for raw in df.preferences:
        sides=parse(raw)
        assert len(sides)==2 and all(len(side)==n for side in sides), (source,n)
        assert all(len(rank)==n and set(rank)==set(range(1,n+1)) for side in sides for rank in side),source
    return df


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--self-gain',choices=['average','stored'],required=True)
    args=parser.parse_args()
    records=[]
    audits=[]
    cache={}
    trunc_sources = {
        "Mallows": ("mallows_gain_with_rank_diff", "mallows_gain_egal"),
        "Mallows MD": ("mallows_MD_gain_with_rank_diff", "mallows_MD_gain_egal"),
        "Mallows MA": ("mallows_MA_gain_with_rank_diff", "mallows_MA_gain_egal"),
        "Reverse Euclidean": ("reverse_euclidean_gain_with_rank_diff", "reverse_euclidean_gain_egal"),
        "Mallows Euclidean": ("mallows_euclidean_gain_with_rank_diff", "mallows_euclidean_gain_egal"),
        "Expectations Euclidean": ("expectations_euclidean_gain_with_rank_diff", "expectations_euclidean_gain"),
    }
    sources=[(model,10,ten) for model,ten,four in MODELS]+[(model,4,four) for model,ten,four in MODELS]+[('Netflix',4,'netflix_preferences_with_rank_diff')]
    for model,n,source in sources:
        df=read(source,n)
        cache[source]=df
        for scheme,count,gain,flag,benefit_list in SCHEMES:
            benefits=df[benefit_list].map(parse)
            assert benefits.map(len).eq(n).all()
            recomputed_count=benefits.map(lambda values:sum(value>0 for value in values))
            np.testing.assert_array_equal(df[count],recomputed_count)
            mask=df[count]>0
            np.testing.assert_array_equal(mask,df[flag]>0)
            average=benefits.map(np.mean)
            maximum=benefits.map(max)
            gain_definition='Average benefit across all n agents (zeros retained within each instance)'
            stored_definition='average'
            if scheme=='Self' and n==4:
                np.testing.assert_allclose(df[gain],maximum)
                stored_definition='maximum'
                if args.self_gain=='stored':
                    average=df[gain]
                    gain_definition='Maximum individual self benefit (stored n=4 definition)'
            else:
                np.testing.assert_allclose(df[gain],average)
            count_stats=describe(df.loc[mask,count]/n)
            gain_stats=describe(average.loc[mask]/n)
            records.append(dict(model=model,n=n,scheme=scheme,total_instances=len(df),prevalent_instances=int(mask.sum()),prevalence=float(mask.mean()),
                                **{'count_'+k:v for k,v in count_stats.items()},**{'gain_'+k:v for k,v in gain_stats.items()},count_divisor=n,gain_divisor=n,
                                count_column=count,gain_column=gain,gain_definition=gain_definition,source='CSV_Files/'+source+'.csv'))
            audits.append(dict(model=model,n=n,scheme=scheme,source='CSV_Files/'+source+'.csv',preference_rows_checked=len(df),stored_gain_definition=stored_definition,reported_gain_definition=gain_definition))
    for model,n,source in sources:
        if n==10:
            count_source,gain_source=trunc_sources[model]
            counts_df=cache[count_source] if count_source in cache else read(count_source,n)
            gains_df=cache[gain_source] if gain_source in cache else read(gain_source,n)
            # Both CSVs contain the exact same original instances in the same order.
            assert counts_df.preferences.equals(gains_df.preferences)
            assert counts_df['sample'].equals(gains_df['sample'])
        else:
            count_source=gain_source=source
            counts_df=gains_df=cache[source]
        count=counts_df.rank_differences.map(lambda raw:sum(value>0 for value in parse(raw)))
        np.testing.assert_array_equal(count,counts_df.trunc_count)
        mask=count>0
        np.testing.assert_array_equal(mask,gains_df.stability_count>1)
        if 'trunc_prevalence' in gains_df:
            np.testing.assert_array_equal(mask,gains_df.trunc_prevalence>0)
        # Check partner differences independently against the prevalence mask.
        differs=[parse(m)!=parse(w) for m,w in zip(gains_df.men_opt_match,gains_df.women_opt_match)]
        np.testing.assert_array_equal(mask,differs)
        # Recompute the same egalitarian cost gap for both market sizes.
        deltas=[]
        for row in gains_df[['preferences','egalitarian_match','men_opt_match','women_opt_match']].itertuples(index=False,name=None):
            men,women=parse(row[0])
            egal,men_opt,women_opt=map(parse,row[1:])
            def men_cost(match):
                return sum(men[i].index(w) for i,w in enumerate(match))
            def women_cost(match):
                return sum(women[w-1].index(i+1) for i,w in enumerate(match))
            deltas.append(men_cost(egal)+women_cost(egal)-men_cost(men_opt)-women_cost(women_opt))
        np.testing.assert_array_equal(deltas,gains_df.trunc_egal)
        count_stats=describe(count.loc[mask]/n)
        gain_stats=describe(gains_df.loc[mask,'trunc_egal']/(2*n))
        records.append(dict(model=model,n=n,scheme='Truncation',total_instances=len(counts_df),prevalent_instances=int(mask.sum()),prevalence=float(mask.mean()),
                            **{'count_'+k:v for k,v in count_stats.items()},**{'gain_'+k:v for k,v in gain_stats.items()},count_divisor=n,gain_divisor=2*n,
                            count_column='trunc_count',gain_column='trunc_egal',gain_definition='Egalitarian truncation gain',
                            source='CSV_Files/'+gain_source+'.csv',count_source='CSV_Files/'+count_source+'.csv'))
        audits.append(dict(model=model,n=n,scheme='Truncation',source='CSV_Files/'+gain_source+'.csv',count_source='CSV_Files/'+count_source+'.csv',
                           preference_rows_checked=len(gains_df),stored_gain_definition='egalitarian gain',reported_gain_definition='Egalitarian truncation gain / (2n)'))
    result=pd.DataFrame(records)
    result['count_source']=result['count_source'].fillna(result['source'])
    scheme_order={name:i for i,name in enumerate(['Self','Accomplice','Two-for-one','Truncation'])}
    model_order={model:i for i,(model,_,_) in enumerate(MODELS)}
    model_order['Netflix']=len(MODELS)
    result['model_order']=result.model.map(model_order)
    result['scheme_order']=result.scheme.map(scheme_order)
    result=result.sort_values(['n','model_order','scheme_order'],ascending=[False,True,True]).drop(columns=['model_order','scheme_order'])
    result.to_csv(OUT/'normalized_statistics.csv',index=False)
    pd.DataFrame(audits).to_csv(OUT/'source_and_metric_audit.csv',index=False)
    text=[
        '# Normalized statistics over prevalent instances',
        '',
        'Counts and permutation gains are divided by n; truncation egalitarian gain is divided by 2n. Each instance has equal weight, pooling all parameter settings.',
        'Prevalence is the fraction of all source instances with at least one successful manipulator of the corresponding type.',
        'Count and gain statistics use only those prevalent instances; no zero-filled heatmap cells enter these summaries.',
        'Permutation gain is the per-instance average benefit across all n agents, then divided by n, except where explicitly noted. Truncation gain uses trunc_egal divided by 2n.',
        'Max is the largest observed value of that per-instance metric, not the maximum individual benefit.',
        '',
    ]
    if args.self_gain=='average':
        text+=['The n=4 files store maximum self benefit in avg_self_benefit. This report recomputes the average from the benefit lists to match n=10.', '']
    else:
        text+=['The stored n=4 self-gain metric is maximum individual benefit; n=10 self gain and all accomplice/two-for-one gains are averages across agents.', '']
    for n in [10,4]:
        text += [f'## n = {n}', '', 'Each statistics cell lists **mean / median / max**.', '', '| Model | Scheme | Prevalent / total | Prevalence | Manipulators / n | Normalized gain |', '|---|---|---:|---:|---:|---:|']
        for row in result[result.n==n].itertuples(index=False):
            count=' / '.join(f'{getattr(row,"count_"+s):.4f}' for s in ['mean','median','max'])
            gain=' / '.join(f'{getattr(row,"gain_"+s):.4f}' for s in ['mean','median','max'])
            text.append(f'| {row.model} | {row.scheme} | {row.prevalent_instances} / {row.total_instances} | {row.prevalence:.2%} | {count} | {gain} |')
        text+=['']
    text+=['## Source files', '', '| Model | n | CSV |','|---|---:|---|']
    for model,n,source in sources:
        text.append(f'| {model} | {n} | CSV_Files/{source}.csv |')
    text+=['', 'The CSV report records the count and gain source for every row, including the paired n=10 truncation sources. Those paired files were verified to contain identical preferences and sample IDs in the same row order.', '']
    (OUT/'statistics_report.md').write_text('\n'.join(text)+'\n')
    print(result[['model','n','scheme','prevalent_instances','total_instances','prevalence','count_mean','count_median','count_max','gain_mean','gain_median','gain_max']].to_string(index=False))


if __name__=='__main__':
    main()
