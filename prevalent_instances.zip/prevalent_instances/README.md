# Figures conditional on prevalent instances

All 51 unique requested PDFs are recreated here. The repeated request for
`reverse_euclidean_number_two_manipulators.pdf` is represented by one PDF.
Original PDFs, notebooks, and input CSVs are unchanged.

For each parameter combination, retain only instances with at least one
successful manipulator of the relevant type, then take the arithmetic mean of
the original per-instance metric and apply the documented normalization.
Self plots condition on positive `num_self_manipulators` or
`self_manipulating_women`; accomplice plots condition on positive
`number_acc_manipulators` or `count_woman`; two-for-one plots condition on
positive `number_two_manipulators` or `Two_for_one`.

Benefit metrics retain their original within-instance definitions. The change
is which instances contribute to the average, rather than a change to how
benefits are averaged within an instance. Likewise, figures of maximum benefit
show the conditional mean of the per-instance maximum.

A parameter cell with no prevalent instances has an undefined conditional mean.
As requested, every figure displays these cells as 0 and includes the full
parameter grid, restoring all previously omitted rows and columns. Color scales
include the displayed zeros. The values CSVs retain blank conditional means
for these cells, so the audit data distinguishes undefined means from genuine zeros.

## Mallows-Euclidean data sources

`mallows_euclidean_number_two_manipulators.pdf` and
`mallows_euclidean_number_two_pairs.pdf` use `CSV_Files/mallows_euclidean_gain.csv`
and phi_m/phi_w axes, following the corrected source instruction. Their pair
counts are normalized by n squared (100) and their manipulator counts by n
(10), matching the corresponding reverse-Euclidean count figures. Other figures retain their
established count divisors; gain normalization follows the rule below.

## Reproducibility and verification

`calculation_manifest.csv` records each figure's source CSV, value column,
prevalence column, normalization divisor, total and retained instance counts,
and number of undefined parameter cells.

Each `*_values.csv` contains the exact conditional means and the total and
prevalent sample sizes for every parameter cell. Blank means correspond to undefined conditional means displayed as 0 in the figures.
The generator independently checks the means against explicit sums divided by
prevalent instance counts. All PDFs were reopened and rendered with macOS
PDFKit for visual review.

To regenerate from the workspace root:

```sh
MPLCONFIGDIR=/private/tmp/prevalent_mpl python3 prevalent_instances/recreate_plots.py
```

Dependencies: pandas, numpy, matplotlib, seaborn.

## Additional truncation figures

Truncation counts are recomputed as the number of positive entries in each
instance's `rank_differences` list. Only instances with a positive count
contribute to the conditional averages. Stored counts, where available, are
checked against the recomputed counts.

For egalitarian truncation figures, `trunc_manipulators` counts partner changes
between the men-optimal and women-optimal stable matchings. Prevalence means
this count is positive; the generator verifies that this agrees with
`stability_count > 1` in each egalitarian source file. The original `trunc_egal`
metric is averaged only over these instances, then divided by 2n (20 for these
n=10 markets).

Self-manipulator counts for markets of size 50 and 70 are checked or computed
from positive entries in the `benefit` lists and normalized by market size.

To create only figures whose PDFs are missing, preserving existing figures:

```sh
MPLCONFIGDIR=/private/tmp/prevalent_mpl python3 prevalent_instances/recreate_plots.py --skip-existing
```

## Gain normalization

All permutation benefit/gain plots divide the conditional mean of the original
per-instance benefit metric by n. All truncation gain plots (`trunc_egal`)
divide by 2n. All gain source markets have n=10, verified from the preference
lists, giving divisors of 10 and 20 respectively. These divisors replace prior
plot divisors; they are not compounded with prior normalization. Existing
within-instance benefit definitions are retained.

Manipulator counts, pair counts, and truncation counts keep their prior
normalization. Undefined conditional means continue to display as 0 on the
full parameter grid.

## Complete preference-profile market-size audit

`verify_market_sizes.py` checks every original preference profile in all 32
source CSVs used by the 51 plots. The audit covers 206,400 instances and checks
both side sizes, ranking lengths, and that each ranking is a permutation of
1 through n. All profiles match their plots' expected market sizes (10, 30,
50, or 70), with zero invalid profiles. The per-source results are recorded in
`market_size_audit.csv`. This verifies market size and ranking validity; it does
not independently identify the preference-generation model from rankings alone.

## Conditional summary statistics

`statistics/statistics_report.md` and `statistics/normalized_statistics.csv`
report mean, median, and maximum normalized manipulator counts and gains,
and prevalence, for all six models at n=10 and n=4 plus Netflix at n=4.
Pair counts are omitted. Statistics pool individual instances across parameter
settings, conditioning counts and gains on the relevant type having at least
one successful manipulator. Prevalence uses all source instances.

Self, accomplice, and two-for-one gains are recomputed as the average of the
per-agent benefit list, including zero benefits within each instance, then
divided by n. The n=4 stored self-gain column used maxima; these statistics
correct it to the same mean definition used at n=10. Truncation gain is the
egalitarian cost gap divided by 2n, checked against costs recomputed from
preferences and stored matchings. All manipulator counts are divided by n.
The permutation gain columns for accomplice and two-for-one were verified to
match recomputed averages at both market sizes. Original CSVs are preserved.
